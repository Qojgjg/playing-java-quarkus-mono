package inveox.exportservice.domain.model.enums;

public enum DigitalLabOrderStatus {

    IN_DELIVERY,LOADED_IN_PROCESS,REJECTED,ACCEPTED;

}