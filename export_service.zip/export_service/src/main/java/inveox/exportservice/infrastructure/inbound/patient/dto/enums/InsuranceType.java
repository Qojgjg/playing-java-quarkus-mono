package inveox.exportservice.infrastructure.inbound.patient.dto.enums;

public enum InsuranceType {
    PUBLIC, PRIVATE, PAID_BY_PATIENT, OTHER
}

