package inveox.exportservice.infrastructure.inbound.patient.dto.enums;

public enum GenderType {
    MALE, FEMALE, OTHER, UNKNOWN
}
